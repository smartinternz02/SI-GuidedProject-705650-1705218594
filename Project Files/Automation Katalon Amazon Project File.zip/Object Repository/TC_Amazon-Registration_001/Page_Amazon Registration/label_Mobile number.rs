<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Mobile number</name>
   <tag></tag>
   <elementGuidId>08346b59-0e7f-43b2-ae0d-d531d25fecd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.a-form-label.auth-mobile-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div[2]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>39e38600-9527-453f-a9fe-62eb78a4d11d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_phone_number</value>
      <webElementGuid>72a50011-31d5-43be-8500-3a09b0c57db1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label auth-mobile-label</value>
      <webElementGuid>8b5ae482-0793-4252-8a26-8050efe1c53a</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Mobile number
          </value>
      <webElementGuid>78235325-ca23-47c1-b772-0ecd3f3de626</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-section a-spacing-base ap_mobile_number_fields&quot;]/div[@class=&quot;a-row&quot;]/label[@class=&quot;a-form-label auth-mobile-label&quot;]</value>
      <webElementGuid>9a10b949-f61b-4628-81a7-8758ee7a1152</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div[2]/div/label</value>
      <webElementGuid>940b68c5-a661-4f21-8527-55eafdf0cc2a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your name'])[1]/following::label[1]</value>
      <webElementGuid>3c1e4d0a-faf8-425f-b9c2-82e7093297df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your name'])[1]/following::label[1]</value>
      <webElementGuid>bcad586f-7850-4546-8ca7-a9b581382f1c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IN +91'])[2]/preceding::label[1]</value>
      <webElementGuid>fb7eb4f1-1e0b-4f39-8e80-9d2a7aebfd0e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your mobile number'])[1]/preceding::label[1]</value>
      <webElementGuid>2d71dfa8-780f-49ce-b616-d8f735f5472f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mobile number']/parent::*</value>
      <webElementGuid>7890d798-6a38-4510-b433-b0db97f03819</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/label</value>
      <webElementGuid>ca4c4a0f-1fc4-49cb-88ce-e1edbaead540</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
            Mobile number
          ' or . = '
            Mobile number
          ')]</value>
      <webElementGuid>a91ea012-d274-4526-834d-5526f74e8482</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
