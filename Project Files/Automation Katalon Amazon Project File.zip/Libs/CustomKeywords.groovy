
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String



def static "com.qa.test.customFunctions.printHello"() {
    (new com.qa.test.customFunctions()).printHello()
}


def static "com.qa.test.customFunctions.printName"(
    	String name	) {
    (new com.qa.test.customFunctions()).printName(
        	name)
}
