<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Your name</name>
   <tag></tag>
   <elementGuidId>f2ae54a8-21a7-4f52-871a-6585ec3619b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.a-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>08c9ddd4-538d-49ea-a2eb-da9aad3bd60d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_customer_name</value>
      <webElementGuid>34d9e771-2e0c-4dea-b7f6-118a32b0e613</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label</value>
      <webElementGuid>c3103756-248c-4960-ae63-8322d2215954</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Your name
    </value>
      <webElementGuid>ed667da0-c6f7-42b9-af00-5ca935fb1834</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/label[@class=&quot;a-form-label&quot;]</value>
      <webElementGuid>c4e37156-2c90-4693-bf3e-f1559029d1e7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div/label</value>
      <webElementGuid>1304bc73-a17c-4658-94ea-e5afda1f1f15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Account'])[1]/following::label[1]</value>
      <webElementGuid>a89268d0-4a49-4bdf-b7d5-d7e40f785c33</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Please Enable Cookies to Continue'])[1]/following::label[1]</value>
      <webElementGuid>70fe4cee-9b89-44d7-a103-27ed9573d74e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your name'])[1]/preceding::label[1]</value>
      <webElementGuid>b5368f54-53b1-4c53-ae13-4eee2f4b3a5a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mobile number'])[1]/preceding::label[1]</value>
      <webElementGuid>0b33dfb2-bba7-42f4-98aa-ebafc37ef283</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Your name']/parent::*</value>
      <webElementGuid>38f4151a-6a60-431c-a828-0d6fb545d03e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label</value>
      <webElementGuid>3496683e-4a64-4fff-b1a0-b13e10d126da</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
      Your name
    ' or . = '
      Your name
    ')]</value>
      <webElementGuid>a7b2ec25-43d9-47f6-9e74-51117c98cc73</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
