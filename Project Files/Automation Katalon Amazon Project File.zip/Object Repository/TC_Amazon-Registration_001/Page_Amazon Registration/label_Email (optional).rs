<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Email (optional)</name>
   <tag></tag>
   <elementGuidId>90db6afa-cf14-49e4-86f1-6fdbf9063ab3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-row.a-spacing-micro > label.a-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div[3]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>de1766e9-028d-4895-8f24-5ad6950ce3fc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_email</value>
      <webElementGuid>44a57325-fa40-4005-8501-06cac6fddfae</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label</value>
      <webElementGuid>2f98949f-c190-4acd-869b-94a449060565</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
              Email (optional)
            </value>
      <webElementGuid>190241f1-b68d-4164-a559-7d2e3cb6e0c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-section a-spacing-base ap_email_fields&quot;]/div[@class=&quot;a-row a-spacing-micro&quot;]/label[@class=&quot;a-form-label&quot;]</value>
      <webElementGuid>7fe3ddbc-13a5-4e4b-8682-24765898f78e</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div[3]/div/label</value>
      <webElementGuid>b8da20c3-fda7-4abb-b9de-00d0703c6685</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your mobile number'])[2]/following::label[1]</value>
      <webElementGuid>cc6032e7-6d35-4ad0-ad14-bac47645e9c6</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The mobile number you entered does not seem to be valid'])[1]/following::label[1]</value>
      <webElementGuid>58b81dc8-baf9-47b9-8d35-499172e879e7</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your email'])[1]/preceding::label[1]</value>
      <webElementGuid>a02bd01e-4ef9-4b92-875c-934cb07f8783</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter a valid email address'])[1]/preceding::label[1]</value>
      <webElementGuid>95fe75b2-2a97-4e7f-9835-05c092245eba</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Email (optional)']/parent::*</value>
      <webElementGuid>2c032b12-beca-42b7-bf38-1c6e5b10bc17</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/label</value>
      <webElementGuid>73312733-d941-4179-9598-9c75ff9f1821</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
              Email (optional)
            ' or . = '
              Email (optional)
            ')]</value>
      <webElementGuid>524b9900-337f-4804-b836-f22824309e93</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
