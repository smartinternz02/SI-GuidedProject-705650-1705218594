<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Your name</name>
   <tag></tag>
   <elementGuidId>175de295-b27e-4fd2-af33-eb56d39e5e86</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.a-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>d4410e0c-88d2-4922-8e4e-d0c020fe2554</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_customer_name</value>
      <webElementGuid>b5dda18f-197b-44b4-8ca4-839fa4fc84d5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label</value>
      <webElementGuid>7b521eda-d819-488c-b500-66fa2743b503</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
      Your name
    </value>
      <webElementGuid>20aaca05-183e-4c0f-96c4-645ff7dd23fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/label[@class=&quot;a-form-label&quot;]</value>
      <webElementGuid>b913a113-1fec-4a19-abba-3a0ee0fe4649</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div/label</value>
      <webElementGuid>68cc43e3-9deb-499e-be6d-6e3491508d6d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Create Account'])[1]/following::label[1]</value>
      <webElementGuid>279a9204-990e-48f9-a994-b54aba991409</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Please Enable Cookies to Continue'])[1]/following::label[1]</value>
      <webElementGuid>ecfc0e7f-6e1b-428f-a855-883fafdeb296</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your name'])[1]/preceding::label[1]</value>
      <webElementGuid>46c1e8b3-f30c-44ab-9668-ed1e195e21b3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mobile number'])[1]/preceding::label[1]</value>
      <webElementGuid>00349d3c-176c-461e-9479-2b2e39bedf46</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Your name']/parent::*</value>
      <webElementGuid>f6177f23-90d1-4bea-bff8-9f4686b21c5b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label</value>
      <webElementGuid>1882b614-605b-492d-9458-ee48487b0349</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
      Your name
    ' or . = '
      Your name
    ')]</value>
      <webElementGuid>18f28c1d-7aae-4647-8f4b-3ba1a13986aa</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
