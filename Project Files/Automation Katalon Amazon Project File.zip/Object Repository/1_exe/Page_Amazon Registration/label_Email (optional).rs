<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Email (optional)</name>
   <tag></tag>
   <elementGuidId>73145343-143d-44d0-aef6-8cf0db2be98a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.a-row.a-spacing-micro > label.a-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div[3]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>36e12169-accb-47d7-b04d-267231bdb187</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_email</value>
      <webElementGuid>cd1cf865-efa1-4493-98bb-88d553f3b859</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label</value>
      <webElementGuid>7deeb384-997e-458f-8d17-fda35a8e9720</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
              Email (optional)
            </value>
      <webElementGuid>a74bf8a1-df7f-42a3-8ad4-bfd1409ec8b4</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-section a-spacing-base ap_email_fields&quot;]/div[@class=&quot;a-row a-spacing-micro&quot;]/label[@class=&quot;a-form-label&quot;]</value>
      <webElementGuid>31c43c41-6884-4789-9195-eefa77f0627f</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div[3]/div/label</value>
      <webElementGuid>18c773a7-b19d-4f42-b309-b51f053d5eca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your mobile number'])[2]/following::label[1]</value>
      <webElementGuid>7ecf2111-c811-4d53-914e-c73e16535bfb</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='The mobile number you entered does not seem to be valid'])[1]/following::label[1]</value>
      <webElementGuid>8487823a-2652-46fe-8987-f7f60dcea2ca</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your email'])[1]/preceding::label[1]</value>
      <webElementGuid>d8fa9c9e-af57-4c3c-bd7e-e342f713e332</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter a valid email address'])[1]/preceding::label[1]</value>
      <webElementGuid>a7e46635-10ab-4abb-8740-d23b5067fb44</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Email (optional)']/parent::*</value>
      <webElementGuid>36ab9d35-f514-4953-8ad2-155caee2d882</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[3]/div/label</value>
      <webElementGuid>6b231122-3da7-459a-a588-b6e08a2a1754</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
              Email (optional)
            ' or . = '
              Email (optional)
            ')]</value>
      <webElementGuid>6b447d72-0c04-4fb3-b44f-e1e4f892e4b4</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
