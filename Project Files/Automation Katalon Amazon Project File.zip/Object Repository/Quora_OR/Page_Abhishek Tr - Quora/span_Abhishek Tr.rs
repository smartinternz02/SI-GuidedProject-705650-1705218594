<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Abhishek Tr</name>
   <tag></tag>
   <elementGuidId>2345ada0-0ecb-46e0-95e3-5fbce674f96c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>a.q-box.Link___StyledBox-t2xg9c-0.dFkjrQ.puppeteer_test_link.qu-color--gray_dark.qu-cursor--pointer.qu-hover--textDecoration--underline > div.q-inlineFlex.qu-alignItems--center.qu-wordBreak--break-word > span > span</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='mainContent']/div[2]/div/div[4]/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/span/span/div/div/div/div/div/a/div/span/span</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
      <webElementGuid>89ea853a-28cd-4a97-af8a-7f0a9f5ff960</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Abhishek Tr</value>
      <webElementGuid>ae44ff57-3046-4710-b147-ad82995d5623</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainContent&quot;)/div[@class=&quot;q-box qu-mt--small&quot;]/div[@class=&quot;q-box qu-bg--white&quot;]/div[@class=&quot;q-box&quot;]/div[2]/div[@class=&quot;q-box qu-pt--medium qu-pb--medium qu-borderBottom&quot;]/div[@class=&quot;q-relative&quot;]/div[@class=&quot;q-box&quot;]/div[1]/div[@class=&quot;q-click-wrapper qu-display--block qu-tapHighlight--none qu-cursor--pointer ClickWrapper___StyledClickWrapperBox-zoqi4f-0 iyYUZT&quot;]/div[@class=&quot;q-flex&quot;]/div[@class=&quot;q-box qu-mb--small&quot;]/div[@class=&quot;q-box spacing_log_answer_header&quot;]/div[@class=&quot;q-box&quot;]/div[@class=&quot;q-flex qu-alignItems--flex-start&quot;]/div[@class=&quot;q-box qu-flex--auto&quot;]/div[@class=&quot;q-box&quot;]/span[@class=&quot;q-box&quot;]/span[@class=&quot;q-text qu-dynamicFontSize--small qu-bold qu-color--gray_dark qu-passColorToLinks&quot;]/div[@class=&quot;q-inlineFlex qu-alignItems--center&quot;]/div[@class=&quot;q-box qu-display--inline&quot;]/div[@class=&quot;q-box qu-display--inline&quot;]/div[@class=&quot;q-relative qu-display--inline puppeteer_popper_reference&quot;]/div[@class=&quot;q-click-wrapper qu-display--inline qu-tapHighlight--white qu-cursor--pointer ClickWrapper___StyledClickWrapperBox-zoqi4f-0 iyYUZT&quot;]/a[@class=&quot;q-box Link___StyledBox-t2xg9c-0 dFkjrQ puppeteer_test_link qu-color--gray_dark qu-cursor--pointer qu-hover--textDecoration--underline&quot;]/div[@class=&quot;q-inlineFlex qu-alignItems--center qu-wordBreak--break-word&quot;]/span[1]/span[1]</value>
      <webElementGuid>cc9b727b-e3b3-4acb-bb9c-1990a9ab1fc5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='mainContent']/div[2]/div/div[4]/div[2]/div/div[2]/div/div/div/div/div/div/div/div/div[2]/div/span/span/div/div/div/div/div/a/div/span/span</value>
      <webElementGuid>933228d2-f4e8-4233-bedf-93af624ac308</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a/div/span/span</value>
      <webElementGuid>21790f55-9fca-4795-9c66-4df8886929ec</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//span[(text() = 'Abhishek Tr' or . = 'Abhishek Tr')]</value>
      <webElementGuid>4441ca20-2d89-4c46-b37a-d266e8919688</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
