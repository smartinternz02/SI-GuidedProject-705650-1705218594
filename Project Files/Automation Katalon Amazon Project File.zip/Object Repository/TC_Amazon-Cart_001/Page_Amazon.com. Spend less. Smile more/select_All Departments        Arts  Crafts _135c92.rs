<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_All Departments        Arts  Crafts _135c92</name>
   <tag></tag>
   <elementGuidId>7fb575a1-6c01-49a9-aefa-fe3eb72441b1</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#searchDropdownBox</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='searchDropdownBox']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>8d792a96-a8a2-495d-b209-b29f506ea77c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-describedby</name>
      <type>Main</type>
      <value>searchDropdownDescription</value>
      <webElementGuid>86fb7e1a-42c6-4317-8cf9-9b816901a02b</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>nav-search-dropdown searchSelect nav-progressive-attrubute nav-progressive-search-dropdown</value>
      <webElementGuid>6f86ff08-64cf-4346-9f49-432391a60ef2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-digest</name>
      <type>Main</type>
      <value>k+fyIAyB82R9jVEmroQ0OWwSW3A=</value>
      <webElementGuid>a71ea13c-62f6-47e4-88d8-0432a9015a12</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-nav-selected</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>966e839b-65d5-4856-9d38-214de80043c1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>searchDropdownBox</value>
      <webElementGuid>05a7a2f3-fc5f-40e6-b631-d74fab301144</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>url</value>
      <webElementGuid>9f2dc517-0ee9-4986-b39e-eba153066370</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>0</value>
      <webElementGuid>0735ef8e-9e08-4a4f-b5e3-287fa94c2437</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Search in</value>
      <webElementGuid>eaced93a-76a4-4863-86d4-bf5b5798e21d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys' Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls' Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men's Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women's Fashion
    </value>
      <webElementGuid>ccd287f4-58db-4e78-8c05-5b759b99104f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;searchDropdownBox&quot;)</value>
      <webElementGuid>5afe72e1-177b-4315-83a7-4c25c466bbb7</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='searchDropdownBox']</value>
      <webElementGuid>f65e0d40-caf0-45b0-a2fe-f3c1503e7851</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='nav-search-dropdown-card']/div/select</value>
      <webElementGuid>0b044cb4-80bd-498e-8ee9-349eb7d5ce98</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>23ae7206-fd14-4664-a9af-f11e84ba8648</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@id = 'searchDropdownBox' and @name = 'url' and @title = 'Search in' and (text() = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;) or . = concat(&quot;
        All Departments
        Arts &amp; Crafts
        Automotive
        Baby
        Beauty &amp; Personal Care
        Books
        Boys&quot; , &quot;'&quot; , &quot; Fashion
        Computers
        Deals
        Digital Music
        Electronics
        Girls&quot; , &quot;'&quot; , &quot; Fashion
        Health &amp; Household
        Home &amp; Kitchen
        Industrial &amp; Scientific
        Kindle Store
        Luggage
        Men&quot; , &quot;'&quot; , &quot;s Fashion
        Movies &amp; TV
        Music, CDs &amp; Vinyl
        Pet Supplies
        Prime Video
        Software
        Sports &amp; Outdoors
        Tools &amp; Home Improvement
        Toys &amp; Games
        Video Games
        Women&quot; , &quot;'&quot; , &quot;s Fashion
    &quot;))]</value>
      <webElementGuid>107ad394-93f3-47e3-884e-28bdfdcd5ee5</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
