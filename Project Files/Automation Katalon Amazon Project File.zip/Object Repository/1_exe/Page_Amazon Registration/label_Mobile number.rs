<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Mobile number</name>
   <tag></tag>
   <elementGuidId>a3948703-9368-4871-bb4b-c0c3ba6aa631</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.a-form-label.auth-mobile-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//form[@id='ap_register_form']/div/div/div[2]/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>0d6760f5-1ec0-4cc1-b891-5f43c01ff6c3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_phone_number</value>
      <webElementGuid>f73180ef-1f0e-463e-9012-ef7711157397</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label auth-mobile-label</value>
      <webElementGuid>6d6a9e38-e619-4699-bb18-d73fa3e7cda3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            Mobile number
          </value>
      <webElementGuid>08e7c21b-626f-4a2c-84e0-e7d1ce6ee32e</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;ap_register_form&quot;)/div[@class=&quot;a-box a-spacing-extra-large&quot;]/div[@class=&quot;a-box-inner&quot;]/div[@class=&quot;a-section a-spacing-base ap_mobile_number_fields&quot;]/div[@class=&quot;a-row&quot;]/label[@class=&quot;a-form-label auth-mobile-label&quot;]</value>
      <webElementGuid>ed9965de-a838-44b6-93ec-38108914fe63</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//form[@id='ap_register_form']/div/div/div[2]/div/label</value>
      <webElementGuid>5c61d85e-a1f6-4a6f-b144-1d04fc3c936d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your name'])[1]/following::label[1]</value>
      <webElementGuid>a55f0b2f-d08b-48ca-8613-cec3a7b42b72</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Your name'])[1]/following::label[1]</value>
      <webElementGuid>d1534eb2-4fd0-404d-8fbd-ebb3857405dd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='IN +91'])[2]/preceding::label[1]</value>
      <webElementGuid>7bf065ee-93db-4a79-90c0-8674fad37d15</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your mobile number'])[1]/preceding::label[1]</value>
      <webElementGuid>dd09fe33-9a69-44fc-b935-50eb410875a2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Mobile number']/parent::*</value>
      <webElementGuid>a9f018e0-8a3a-4da8-bf0c-538fdba38314</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[2]/div/label</value>
      <webElementGuid>862990b5-0a91-4653-a53f-272b7fe38b78</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
            Mobile number
          ' or . = '
            Mobile number
          ')]</value>
      <webElementGuid>e9aa39c5-9b64-4aa9-90e7-4315e93d9e47</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
