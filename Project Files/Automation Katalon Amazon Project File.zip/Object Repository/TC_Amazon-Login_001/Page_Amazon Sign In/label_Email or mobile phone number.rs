<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_Email or mobile phone number</name>
   <tag></tag>
   <elementGuidId>4ec8275f-1eb2-4b8a-bbea-818c7ccef799</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>label.a-form-label</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div/label</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>label</value>
      <webElementGuid>89ff82c4-7e96-42a4-b3fb-7ec055ca19fb</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>for</name>
      <type>Main</type>
      <value>ap_email</value>
      <webElementGuid>1d96b22d-95af-468b-83d1-66945939addf</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>a-form-label</value>
      <webElementGuid>67a69262-4b7f-4128-99c1-f58bdcfea74f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
              Email or mobile phone number
            </value>
      <webElementGuid>08085eca-7a5a-4567-a0bc-c91d471b5697</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;authportal-main-section&quot;)/div[@class=&quot;a-section auth-pagelet-container&quot;]/div[@class=&quot;a-section a-spacing-base&quot;]/div[@class=&quot;a-section&quot;]/form[@class=&quot;auth-validate-form auth-real-time-validation a-spacing-none&quot;]/div[@class=&quot;a-section&quot;]/div[@class=&quot;a-box&quot;]/div[@class=&quot;a-box-inner a-padding-extra-large&quot;]/div[@class=&quot;a-row a-spacing-base&quot;]/label[@class=&quot;a-form-label&quot;]</value>
      <webElementGuid>5d24b32e-1d78-4de9-ad15-ae246c8b966b</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='authportal-main-section']/div[2]/div[2]/div/form/div/div/div/div/label</value>
      <webElementGuid>97dfb69e-353d-47de-baf9-3aafec223cc2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Sign in'])[1]/following::label[1]</value>
      <webElementGuid>d9836e58-2e6e-4e1f-8229-abc06518e95c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Passkey error'])[1]/following::label[1]</value>
      <webElementGuid>d5fc850b-cb33-443e-ba53-dd1d1eb0533c</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Enter your email or mobile phone number'])[1]/preceding::label[1]</value>
      <webElementGuid>a98f5cfa-6e6e-4291-90dc-cf794c66b5d1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Email or mobile phone number']/parent::*</value>
      <webElementGuid>9c3cd19d-ec97-46f7-9c91-14d22b5de175</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//label</value>
      <webElementGuid>67e549bb-119c-4bbe-99c9-10f91d7dae1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//label[(text() = '
              Email or mobile phone number
            ' or . = '
              Email or mobile phone number
            ')]</value>
      <webElementGuid>17359186-4692-4700-803e-f0e3aa1201d8</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
